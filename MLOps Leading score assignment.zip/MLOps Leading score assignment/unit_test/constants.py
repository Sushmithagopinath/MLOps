# You can create more variables according to your project. The following are the basic variables that have been provided to you
DB_PATH = 'Assignment/Assignment/01_data_pipeline/scripts'
DB_FILE_NAME = 'lead_scoring_data_cleaning.db'
UNIT_TEST_DB_FILE_NAME = ''
DATA_DIRECTORY = 'Assignment/Assignment/01_data_pipeline/scripts/data/leadscoring.csv'
INTERACTION_MAPPING = 'Assignment/Assignment/01_data_pipeline/scripts/interaction_mapping.csv'
INDEX_COLUMNS_TRAINING = []
INDEX_COLUMNS_INFERENCE = []
NOT_FEATURES = []




